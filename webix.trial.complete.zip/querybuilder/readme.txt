Webix Query Builder v.5.2.2
=================================

http://webix.com/querybuilder

If you don't know where to start - check 

- http://docs.webix.com/desktop__querybuilder.html



-### Building from sources

-Full package includes all sources in the "sources" folder.
-To build new file in codebase folder run next

-       npm install
-       npm run pack



### Updating the component

To get the latest version of the component, you can login 
into the client's area at http://webix.com/clients/

There you can download the latest package, or register as a Webix developer
and get npm access to the latest and all further versions of the package.  



### Support

If you have questions about functionality of the component 
or have some issue with API and behavior of the component,
please contact us at support@webix.com



(c) XB Software Ltd. 2017