<?php

if (is_dir("/var/sandbox/"))
	$root_folder = "/var/sandbox/";
else
	$root_folder = "../";